import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-post-matric',
  templateUrl: './post-matric.component.html',
  styleUrls: ['./post-matric.component.css']
})
export class PostMatricComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
