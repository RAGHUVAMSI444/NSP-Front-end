import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-merit-based',
  templateUrl: './merit-based.component.html',
  styleUrls: ['./merit-based.component.css']
})
export class MeritBasedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
