export interface IStudent {
    name:string
    dob:Date
    gender:string
    mobileNumber:string
    email:string
    instituteCode:number
    aadhaar:string
    bankIFSC:string
    accountNo:string
    bankName:string
    password:string
}
