import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pragati',
  templateUrl: './pragati.component.html',
  styleUrls: ['./pragati.component.css']
})
export class PragatiComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
