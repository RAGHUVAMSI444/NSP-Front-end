export interface IStudentStatus {
    approvalId:number
    applicationId:number
    approvedByInstitute:number
    approvedByNodalOfficer:number
    approvedByMinistry:number
}
