export interface IInstituteStatus {
    instituteApprovalId:number
    instituteId:number
    approvedByNodalOfficer:number
    approvedByMinistry:number
}