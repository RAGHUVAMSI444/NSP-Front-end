export interface Iapplicationforinstitute {
        applicationId:number
        studentId: number,
        scholarshipId: number,
        presentCourse: string
}
