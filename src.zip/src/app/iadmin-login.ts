export interface IAdminLogin {
    Name:string
    Password:string
}