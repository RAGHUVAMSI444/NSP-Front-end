export interface IStudentLogin {
    Aadhaar:string
    Password:string
}
