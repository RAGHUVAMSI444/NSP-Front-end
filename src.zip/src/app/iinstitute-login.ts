export interface IInstituteLogin {
    Institutecode:number
    Password:string    
}